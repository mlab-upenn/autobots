#include "mbed.h"
#include "rtos.h"
#include "driver.h"
#include "encoder.h"
#include "shared.h"
#include "imu.h"
Ticker ticker_encoder;
//Ticker ticker_forward_sup;

int main (void)
{
    pc.baud(115200);
    reset_odo();
    former_l = left_encoder.read();
    former_r = right_encoder.read();
    ticker_encoder.attach_us(&getEncoderTicks, 10000);
    Thread t3(motor_controller);
    Thread t4(displayEncoderTicks);
    getImuValues();
}

