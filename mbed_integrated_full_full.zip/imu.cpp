#include "imu.h"


    imu_9dof::imu_9dof():cmp(p28, p27),acc(p28, p27), gyr(p28, p27), imuFilter(0.1,10)
    {
     //ID Buffer
        char buffer[3];
       cmp.setDefault();
        wait(0.1);
        cmp.getAddress(buffer);
        if (acc.setPowerControl(0x00)){
        exit(0);
        }
        wait(.001);
        
        if(acc.setDataFormatControl(0x0B)){
        exit(0);
        }
        wait(.001);
         
        if(acc.setDataRate(ADXL345_3200HZ)){
        exit(0);
        }
        wait(.001);
         
        if(acc.setPowerControl(MeasurementMode)) {
        exit(0);
        } 
        gyr.setLpBandwidth(LPFBW_256HZ);
        wait(1);
        
    }
    imu_9dof::imu_9dof(PinName Tx, PinName Rx, double rate, double gyroscopeMeasurementError):cmp(Tx, Rx),acc(Tx, Rx),gyr(Tx, Rx),imuFilter(rate,gyroscopeMeasurementError)
    {
     //ID Buffer
        char buffer[3];
       cmp.setDefault();
        wait(0.1);
        cmp.getAddress(buffer);
        if (acc.setPowerControl(0x00)){
        exit(0);
        }
        wait(.001);
        
        if(acc.setDataFormatControl(0x0B)){
        exit(0);
        }
        wait(.001);
         
        if(acc.setDataRate(ADXL345_3200HZ)){
        exit(0);
        }
        wait(.001);
         
        if(acc.setPowerControl(MeasurementMode)) {
        exit(0);
        } 
        gyr.setLpBandwidth(LPFBW_256HZ);
        wait(1);
        
    }

    std::string imu_9dof::getAcclr()
    {
        int readings[3];
        cmp.readData(readings);
        wait(0.05);
        return imu_9dof::intToString(readings,3);
    }
    
    std::string imu_9dof::getMagnt()
    {
        int readings[3];
        acc.getOutput(readings);
        wait(0.05);
        return imu_9dof::intToString(readings,3);
        
    }

    std::string imu_9dof::getGyro()
    {
        int readings[3];
        readings[0] = gyr.getGyroX();
        readings[1] = gyr.getGyroY();
        readings[2] = gyr.getGyroZ();
        wait(0.05);
        return imu_9dof::intToString(readings,3);        
    }
    
    std::string imu_9dof::getRollPitchYaw(int * accd, int * gyrod)
    {
         double gyroscale = 3.14/360;
         double acclscale = 0.001;
         imuFilter.updateFilter(gyrod[0]*gyroscale,gyrod[1]*gyroscale,gyrod[2]*gyroscale,accd[0]*acclscale ,accd[1]*acclscale ,accd[2]*acclscale );
                imuFilter.computeEuler();
                std::stringstream ss;
                ss << " ";
                ss << imuFilter.getRoll();
                ss << " ";
                ss << imuFilter.getPitch();
                ss << " ";
                ss << imuFilter.getYaw();
                ss << " ";
                return ss.str();
    }
    
    std::string imu_9dof::getAllReadings()
    {
        int mgtd[3];
        int accd[3];
        int gyrod[3];
        cmp.readData(mgtd);
        wait(0.05);
        acc.getOutput(accd);
        wait(0.05);
        gyrod[0] = gyr.getGyroX();
        gyrod[1] = gyr.getGyroY();
        gyrod[2] = gyr.getGyroZ();
        std::string s = imu_9dof::intToString(mgtd, 3);
        s += imu_9dof::intToString(accd, 3);
        s += imu_9dof::intToString(gyrod, 3);
        s += getRollPitchYaw(gyrod,accd);
        return s; 
 
    }

        
    std::string imu_9dof::intToString(int* reading, unsigned N)
    {
        std::string s ;
        for (int i = 0 ; i < N ; i ++)
        {
            std::stringstream ss;
            ss << (int16_t) reading[i];
            s += ss.str() + " ";
        }
       return s;
    }
    
    
    void getImuValues()
    {
        int i = 0;
            imu_9dof imu;
        while(1) {
            std::string s  = " BIMU " + imu.getAllReadings() + " EIMU ";
            prints(s);
            wait(0.2);
        }        
    }

    void getImuValues(void const *)
    {
        pc.printf("coming ");
        int i = 0;
            imu_9dof imu;
        while(true) {
            std::string s  = " BIMU " + imu.getAllReadings() + " EIMU ";
            prints(s);
        }        
    }
