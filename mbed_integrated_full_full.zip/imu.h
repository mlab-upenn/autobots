#include <iostream>
#include "mbed.h"
#include "rtos.h"
#include "HMC5843.h"
#include "ADXL345.h"
#include "ITG3200.h"
#include "IMUfilter.h"
#include "shared.h"
#include <sstream>      // std::stringstream

class imu_9dof{
    
    public:
    imu_9dof();    
    imu_9dof(PinName Rx, PinName Tx, double rate, double gyroscopeMeasurementError);    
    std::string getAcclr();
    std::string getMagnt();
    std::string getGyro();
    std::string imu_9dof::getAllReadings();
    std::string getRollPitchYaw(int * accd, int * gyrod);
    
private:

    std::string intToString(int* reading, unsigned N);
    
    
HMC5843 cmp;
ADXL345 acc;
ITG3200 gyr;    
IMUfilter imuFilter;

};

    void getImuValues(void const *);
    void getImuValues();
