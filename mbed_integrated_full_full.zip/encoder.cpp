#include "encoder.h"
unsigned int r_count=0;
unsigned int l_count=0;
int prev_r_count=0;
int prev_l_count=0;
int delta_l = 0;
int delta_r = 0;
float former_l = 0;
float former_r = 0;
float rate = 1;

float get_ratio(int left, int right) {
    // might need mutex for r/w delta_l/r
    float ratio;
    if (right != 0) {
        ratio = (float)left / right;
    } else if (left == 0) {
        ratio = 1;
    } else {
        ratio = 25;
    }
    return ratio;
    }


void updateEncoderTicks()
{
    delta_l = l_count - prev_l_count;
    delta_r = r_count - prev_r_count;
    prev_l_count = l_count;
    prev_r_count = r_count;//19.182 counts/inch
    rate = get_ratio(delta_l, delta_r);
//    pc.printf("encoder: left = %d, right = %d\r\n", delta_l, delta_r);
//    pc.printf("encoder: tleft = %d, tright = %d\r\n", l_count, r_count);
        std::stringstream ss;
        ss <<"BENC ";
        ss << delta_l;
        ss <<"@";
        ss << delta_r;
        ss <<" EENC\n";
        std::string s = ss.str() ;
        prints(s);

}

void getEncoderTicks(){
    int i = 0;
    float avg_l = 0;
    float avg_r = 0;
    for (i = 0; i < 5; i++ ){
            avg_l += left_encoder.read();
            avg_r += right_encoder.read();
            wait(0.001f); // every 1 ms
        }
    avg_l = avg_l / 5.0;
    avg_r = avg_r / 5.0;
//    pc.printf("left avg: %f;  right avg: %f\r\n", avg_l, avg_r);
//    pc.printf("left former: %f;  right former: %f\r\n", former_l, former_r);
    if (fabs(avg_l - former_l) > 0.9 ) {
        l_count++;
//        led1 = !led1;
        }
    if (fabs(avg_r - former_r) > 0.9 ) { 
        r_count++;
//        led2 = !led2;
        }
    former_l = avg_l;
    former_r = avg_r;
    }
void reset_odo(){
    __disable_irq();
    l_count=0;
    r_count=0;
    __enable_irq();
    prev_r_count=0;
    prev_l_count=0;
}

void displayEncoderTicks(void const *) {

    while(1){
        updateEncoderTicks();
        Thread::wait(100);
    }
    
}

